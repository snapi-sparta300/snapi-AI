# hand > hand object Detection first version
https://universe.roboflow.com/jinseows/hand-aobxu

Provided by a Roboflow user
License: CC BY 4.0

