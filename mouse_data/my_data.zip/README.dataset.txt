# Mouse > confused solution version
https://universe.roboflow.com/jinseows/mouse-2cgah

Provided by a Roboflow user
License: CC BY 4.0

